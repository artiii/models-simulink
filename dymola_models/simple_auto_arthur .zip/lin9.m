!dymosim -l
[A,B,C,D]=tloadlin;
flipud(esort(eig(A)))